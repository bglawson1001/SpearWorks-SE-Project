Thank you for purchasing one of my game assets!

Please check out my website:
https://selieltheshaper.weebly.com/

You can find the full collection on itch.io:
https://seliel-the-shaper.itch.io/

If you need any help figuring things out, have any questions, or just want to see what I'm up to, please visit my Patreon, Ko-fi, or Twitter!
https://www.patreon.com/selieltheshaper
https://ko-fi.com/selieltheshaper
https://twitter.com/SelieltheShaper